package co.min.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface cominMapper {
	public String main();
}
