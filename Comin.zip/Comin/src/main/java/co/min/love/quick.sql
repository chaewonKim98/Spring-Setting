
DROP TABLE tbl_user CASCADE;

SET foreign_key_checks = 0;
drop table dic_tbl CASCADE;
SET foreign_key_checks = 1;

show tables;

create table tbl_user(
	name varchar(30) not null,
	Ic_num varchar(50) not null,
	num varchar(30) not null,
	primary key(num)
);

insert into tbl_user values('coco','980729-123456','1234-1234')
insert into tbl_user values('mini','980729-123456','1234-1235')

select * from tbl_user;

create table quick_user(
	q_name varchar(30) not null, 
	age varchar(30) not null,
	q_num varchar(30) not null, --오토바이 유저 번호
	auto varchar(30) not null,  --차종 
	a_num varchar(30) not null, --번호판
	primary key(q_num)
);
insert into quick_user values('이명박','25','1541-1512','베스파','15허1234')
insert into quick_user values('박그네','26','1512-1541','딸배','13허1591')