package co.min.love;

import javax.inject.Inject;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import co.min.mapper.cominMapper;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class LoveController {
	
	@Inject
	private cominMapper cominMapper;
	
	@RequestMapping("/")
	public String main() {
		return "home";
	}

	
	

}
